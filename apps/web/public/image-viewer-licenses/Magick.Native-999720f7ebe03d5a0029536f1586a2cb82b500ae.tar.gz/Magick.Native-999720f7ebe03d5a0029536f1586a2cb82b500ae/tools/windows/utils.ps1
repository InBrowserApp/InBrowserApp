# Copyright Dirk Lemstra https://github.com/dlemstra/Magick.Native.
# Licensed under the Apache License, Version 2.0.

function fullPath($path)
{
    return "$PSScriptRoot\..\..\$path"
}
