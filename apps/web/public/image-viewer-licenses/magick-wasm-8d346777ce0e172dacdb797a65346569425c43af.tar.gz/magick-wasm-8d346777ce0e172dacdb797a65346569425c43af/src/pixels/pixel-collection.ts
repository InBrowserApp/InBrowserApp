/*
  Copyright Dirk Lemstra https://github.com/dlemstra/magick-wasm.
  Licensed under the Apache License, Version 2.0.
*/

import { Disposable } from '../internal/disposable';
import { Exception } from '../internal/exception/exception';
import { IDisposable } from '../disposable';
import { ImageMagick } from '../image-magick';
import { IMagickImage } from '../magick-image';
import { MagickColor, IMagickColor } from '../magick-color';
import { NativeInstance } from '../native-instance';
import { NativePointer, quantumArray } from '@dlemstra/magick-native';
import { PixelChannel } from '../enums/pixel-channel';
import { Quantum } from '../quantum';
import { _castToSize } from '../internal/native/size';
import { _withQuantumArray } from '../internal/native/array';
import { _withString } from '../internal/native/string';

/**
 * Interface that can be used to access the individual pixels of an image.
 */
export interface IPixelCollection extends IDisposable {
    /**
     * Returns the pixels at the specified area.
     * @param x The X coordinate.
     * @param y The Y coordinate.
     * @param width The width of the area.
     * @param height The height of the area.
     * @returns The quantum array of the area.
     */
    getArea(x: number, y: number, width: number, height: number): quantumArray;

    /**
     * Returns the pixels at the specified area.
     * @param x The X coordinate.
     * @param y The Y coordinate.
     * @param width The width of the area.
     * @param height The height of the area.
     * @returns The readonly quantum array of the area.
     */
    getReadOnlyArea(x: number, y: number, width: number, height: number): Readonly<quantumArray>;

    /**
     * Returns the index of the specified channel. Returns null if not found.
     * @param channel The channel to get the index o.
     * @returns The index of the specified channel. Returns null if not found.
     */
    getChannelIndex(channel: PixelChannel): number;

    /**
     * Returns the color at the specified coordinate.
     * @param x The X coordinate of the pixel.
     * @param y The Y coordinate of the pixel.
     * @returns The color of the pixel.
     */
    getColor(x: number, y: number): IMagickColor | null;

    /**
     * Returns the pixel at the specified coordinate.
     * @param x The X coordinate of the pixel.
     * @param y The Y coordinate of the pixel.
     * @returns The quantum array of the pixel.
     */
    getPixel(x: number, y: number): quantumArray;

    /**
     * Changes the values of the specified pixels.
     * @param x The X coordinate of the area.
     * @param y The Y coordinate of the area.
     * @param width The width of the area.
     * @param height The height of the area.
     * @param quantumPixels The values of the pixels.
     */
    setArea(x: number, y: number, width: number, height: number, quantumPixels: quantumArray): void;

    /**
     * Changes the values of the specified pixels.
     * @param x The X coordinate of the area.
     * @param y The Y coordinate of the area.
     * @param width The width of the area.
     * @param height The height of the area.
     * @param numberPixels The values of the pixels.
     */
    setArea(x: number, y: number, width: number, height: number, numberPixels: number[]): void;

    /**
     *Changes the value of the specified pixel.
     * @param x The X coordinate of the pixel.
     * @param y The Y coordinate of the pixel.
     * @param quantumPixels The values of the pixel.
     */
    setPixel(x: number, y: number, quantumPixels: quantumArray): void;

    /**
     *Changes the value of the specified pixel.
     * @param x The X coordinate of the pixel.
     * @param y The Y coordinate of the pixel.
     * @param numberPixels The values of the pixel.
     */
    setPixel(x: number, y: number, numberPixels: number[]): void;

    /**
     * Returns the values of the pixels as a byte array.
     * @param x The X coordinate of the area.
     * @param y The Y coordinate of the area.
     * @param width The width of the area.
     * @param height The height of the area.
     * @param mapping The mapping of the pixels.
     */
    toByteArray(x: number, y: number, width: number, height: number, mapping: string): Uint8Array | null;
}

export class PixelCollection extends NativeInstance implements IPixelCollection {
    private readonly image: IMagickImage;

    private constructor(image: IMagickImage) {
        const instance = Exception.usePointer(exception => {
            return ImageMagick._api._PixelCollection_Create(image._instance, exception);
        });
        const disposeMethod = ImageMagick._api._PixelCollection_Dispose;

        super(instance, disposeMethod);

        this.image = image;
    }

    /** @internal */
    static _create(image: IMagickImage): PixelCollection {
        return new PixelCollection(image);
    }

    /** @internal */
    static _use<TReturnType>(image: IMagickImage, func: (pixels: IPixelCollection) => TReturnType): TReturnType;
    /** @internal */
    static _use<TReturnType>(image: IMagickImage, func: (pixels: IPixelCollection) => Promise<TReturnType>): Promise<TReturnType>;
    static _use<TReturnType>(image: IMagickImage, func: (pixels: IPixelCollection) => TReturnType | Promise<TReturnType>): TReturnType | Promise<TReturnType> {
        const pixels = new PixelCollection(image);
        return Disposable._disposeAfterExecution(pixels, func);
    }

    /** @internal */
    static _map(image: IMagickImage, mapping: string, func: (instance: number) => void): void {
        const pixels = new PixelCollection(image);
        try {
            pixels.use(0, 0, image.width, image.height, mapping, instance => {
                func(Number(instance));
            });
        }
        finally {
            pixels.dispose();
        }
    }

    getArea(x: number, y: number, width: number, height: number): quantumArray {
        return Exception.usePointer(exception => {
            const instance = Number(ImageMagick._api._PixelCollection_GetArea(this._instance, _castToSize(x), _castToSize(y), _castToSize(width), _castToSize(height), exception));
            const count = Number(width * height * this.image.channelCount);
            return ImageMagick._api.HEAPU8.subarray(instance, instance + count);
        });
    }

    getReadOnlyArea(x: number, y: number, width: number, height: number): Readonly<quantumArray> {
        return Exception.usePointer(exception => {
            const instance = Number(ImageMagick._api._PixelCollection_GetReadOnlyArea(this.image._instance, _castToSize(x), _castToSize(y), _castToSize(width), _castToSize(height), exception));
            const count = Number(width * height * this.image.channelCount);
            return ImageMagick._api.HEAPU8.subarray(instance, instance + count);
        });
    }

    getChannelIndex(channel: PixelChannel): number {
        return this.image._channelOffset(channel);
    }

    getColor(x: number, y: number): IMagickColor | null {
        const area = this.getArea(x, y, 1, 1);
        const data = Array.from(area);
        const index = this.image._channelOffset(PixelChannel.Index);

        if (index >= 0)
            data.splice(index, 1);

        if (data.length === 0)
            return null;

        if (data.length === 1)
            return new MagickColor(data[0], data[0], data[0]);

        if (data.length === 2)
            return new MagickColor(data[0], data[0], data[0], data[1]);

        const hasBlackChannel = this.image._channelOffset(PixelChannel.Black) >= 0;
        const hasAlphaChannel = this.image._channelOffset(PixelChannel.Alpha) >= 0;

        if (hasBlackChannel)
        {
            if (data.length === 4 || !hasAlphaChannel)
                return new MagickColor(data[0], data[1], data[2], data[3], Quantum.max);

            return new MagickColor(data[0], data[1], data[2], data[3], data[4]);
        }

        if (data.length === 3 || !hasAlphaChannel)
            return new MagickColor(data[0], data[1], data[2]);

        return new MagickColor(data[0], data[1], data[2], data[3]);
    }

    getPixel(x: number, y: number): quantumArray {
        return this.getArea(x, y, 1, 1);
    }

    setArea(x: number, y: number, width: number, height: number, quantumPixels: quantumArray): void;
    setArea(x: number, y: number, width: number, height: number, numberPixels: number[]): void;
    setArea(x: number, y: number, width: number, height: number, quantumPixelsOrNumberPixels: quantumArray | number[]): void {
        Exception.usePointer(exception => {
            const pixels = (quantumPixelsOrNumberPixels instanceof Uint8Array) ? quantumPixelsOrNumberPixels : new Uint8Array(quantumPixelsOrNumberPixels);
            _withQuantumArray(pixels, pixelsPtr => {
                const length = _castToSize(pixels.length);
                ImageMagick._api._PixelCollection_SetArea(this._instance, _castToSize(x), _castToSize(y), _castToSize(width), _castToSize(height), pixelsPtr, length, exception);
            });
        });
    }

    setPixel(x: number, y: number, quantumPixels: quantumArray): void;
    setPixel(x: number, y: number, numberPixels: number[]): void;
    setPixel(x: number, y: number, quantumPixelsOrNumberPixels: quantumArray | number[]): void {
        if (quantumPixelsOrNumberPixels instanceof Uint8Array)
            this.setArea(x, y, 1, 1, quantumPixelsOrNumberPixels);
        else
            this.setArea(x, y, 1, 1, quantumPixelsOrNumberPixels);
    }

    toByteArray(x: number, y: number, width: number, height: number, mapping: string): Uint8Array | null {
        return this.use(x, y, width, height, mapping, instance => {
            if (instance === ImageMagick._api._NullPointer)
                return null;

            const count = Number(width * height * mapping.length);
            const nativeInstance = Number(instance);
            return ImageMagick._api.HEAPU8.slice(nativeInstance, nativeInstance + count);
        });
    }

    private use<TReturnType>(x: number, y: number, width: number, height: number, mapping: string, func: (instance: NativePointer) => TReturnType): TReturnType | null {
        return _withString(mapping, mappingPtr => {
            return Exception.use(exception => {
                let instance = ImageMagick._api._PixelCollection_ToByteArray(this._instance, _castToSize(x), _castToSize(y), _castToSize(width), _castToSize(height), mappingPtr, exception.ptr);

                return exception.check(() => {
                    const result = func(instance);
                    instance = ImageMagick._api._MagickMemory_Relinquish(instance);
                    return result;
                }, () => {
                    instance = ImageMagick._api._MagickMemory_Relinquish(instance);
                    return null;
                });
            });
        });
    }
}
