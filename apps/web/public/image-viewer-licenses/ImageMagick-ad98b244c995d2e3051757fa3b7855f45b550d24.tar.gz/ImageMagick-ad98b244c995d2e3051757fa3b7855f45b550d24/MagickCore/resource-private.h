/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.

  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at

    https://imagemagick.org/license/

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

  MagickCore private resource methods.
*/
#ifndef MAGICKCORE_RESOURCE_PRIVATE_H
#define MAGICKCORE_RESOURCE_PRIVATE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#if !defined(MagickFormatExtent)
# define MagickFormatExtent  64
#endif

extern MagickExport MagickBooleanType
  IsFileResourceIdentityValid(const char *);

extern MagickPrivate MagickBooleanType
  ResourceComponentGenesis(void);

extern MagickPrivate void
  ResourceComponentTerminus(void);

extern MagickExport void
  AsynchronousResourceComponentTerminus(void);

#ifdef FUZZING_BUILD_MODE_UNSAFE_FOR_PRODUCTION
extern MagickExport void
  ResetMagickResourceCounters(void);
#endif

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif
