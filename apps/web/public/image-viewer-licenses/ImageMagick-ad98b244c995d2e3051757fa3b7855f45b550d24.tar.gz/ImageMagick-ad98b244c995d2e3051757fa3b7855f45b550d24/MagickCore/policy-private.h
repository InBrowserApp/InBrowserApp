/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.

  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at

    https://imagemagick.org/license/

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

  MagickCore private policy methods.
*/
#ifndef MAGICKCORE_POLICY_PRIVATE_H
#define MAGICKCORE_POLICY_PRIVATE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#include "MagickCore/quantum-private.h"
#include "MagickCore/resource-private.h"
#include "MagickCore/string-private.h"
#include "MagickCore/utility-private.h"

#if defined(MAGICKCORE_ZERO_CONFIGURATION_SUPPORT)
/*
  Zero configuration security policy.  Discussion @
  https://imagemagick.org/script/security-policy.php.
*/
static const char
  *ZeroConfigurationPolicy = \
"<policymap> \
</policymap>";
#endif

extern MagickExport MagickBooleanType
  IsPathAuthorized(const PolicyRights,const char *);

extern MagickPrivate MagickBooleanType
  PolicyComponentGenesis(void);

extern MagickPrivate void
  PolicyComponentTerminus(void);

static inline ssize_t GetShredPasses(void)
{
  char
    *option;

  ssize_t
    policy_passes = 0,
    env_passes = 0,
    passes;

  option=GetPolicyValue("system:shred");
  if (option != (char *) NULL)
    {
      policy_passes=(ssize_t) StringToLong(option);
      option=DestroyString(option);
      if (policy_passes < 0)
        return(0);
    }
  option=GetEnvironmentValue("MAGICK_SHRED_PASSES");
  if (option != (char *) NULL)
    {
      env_passes=(ssize_t) StringToLong(option);
      option=DestroyString(option);
      if (env_passes < 0)
        return(0);
    }
  passes=MagickMax(policy_passes,env_passes);
  return(passes);
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif
